Using:  Bootstrap
        Jquery
        Moment.js

This program displays an input form for a user to enter:
        Train Name
        Destination
        First Train Time -- in military time
        Frequency -- in minutes

Firebase is used to store the data. Any user(s) can access the same data.

An arrival time and minutes until arrival is claculated and displayed on the screen for all trains in the databse:
    TrainName, Desitnation, Arrival Time, Minutes Away

Moment.js is used to calculate/convert times.
